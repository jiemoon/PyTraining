#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
#
# Authors: limanman
# OsChina: http://my.oschina.net/pydevops/
# Purpose:
#
"""
from app import db as _db
from app import create_app
from config import config
from flask_script import Manager


app = create_app()
manager = Manager(app)


@manager.command
def db(command):
    if command == 'init':
        _db.create_all()
    if command == 'drop':
        _db.drop_all()

if __name__ == '__main__':
    manager.run()
