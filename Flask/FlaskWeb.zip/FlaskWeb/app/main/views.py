#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
#
# Authors: limanman
# OsChina: http://my.oschina.net/pydevops/
# Purpose:
#
"""
from . import main
from flask import render_template


@main.route('/', methods=['GET', 'POST'])
def index():
    return render_template('index.html')
