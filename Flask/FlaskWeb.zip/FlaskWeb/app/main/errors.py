#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
#
# Authors: limanman
# OsChina: http://my.oschina.net/pydevops/
# Purpose:
#
"""
from . import main
from flask import render_template


@main.app_errorhandler(404)
def page_not_found(e):
    return render_template('errors/404.html')


@main.app_errorhandler(500)
def server_internal_error(e):
    return render_template('errors/500.html')
