#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
#
# Authors: limanman
# OsChina: http://my.oschina.net/pydevops/
# Purpose:
#
"""
from flask import Blueprint

main = Blueprint('main', __name__, template_folder='templates', static_folder='static')

from . import views, errors
