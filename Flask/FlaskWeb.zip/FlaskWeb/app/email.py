#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
#
# Authors: limanman
# OsChina: http://my.oschina.net/pydevops/
# Purpose:
#
"""
from . import mail
from flask_mail import Message
from flask import render_template


def send_mail(to, subject, template, **kwargs):
    msg = Message(recipients=[to], subject=subject)
    msg.body = render_template('.'.join(template, 'txt'))
    msg.html = render_template('.'.join(template, 'html'))
    mail.send(msg)
