#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
#
# Authors: limanman
# OsChina: http://my.oschina.net/pydevops/
# Purpose:
#
"""


# 说明: Flask扩展配置基类
class __Config(object):
    # 说明: 用类变量形式设置Flask扩展配置
    #
    # For flask-bootstrap
    #
    # BOOTSTRAP_USE_MINIFIED = True
    # 说明: 使用安装时本地的BOOTSTRAP
    # BOOTSTRAP_SERVE_LOCAL = False
    # BOOTSTRAP_LOCAL_SUBDOMAIN = None
    # BOOTSTRAP_CDN_FORCE_SSL = True
    # 说明: 请求静态文件添加版本字符串
    # BOOTSTRAP_QUERYSTRING_REVVING = True
    #
    # For flask-wtf
    #
    # 说明: 启用CSRF跨站请求伪造保护
    CSRF_ENABLED = True
    # 说明: 用于生成加密令牌加密保护
    SECRET_KEY = '8eDi7TQTCijidOOKBvBloMnHMFL72mjM'
    #
    # For flask-sqlalchemy
    #
    # 说明: 设置连接字符串
    # SQLALCHEMY_DATABASE_URI = 'mysql://root:root@10.2.5.51/xmdevops'
    # 说明: 设置关联多个数据库
    # SQLALCHEMY_BINDS = {}
    # 说明: 调试输出所有操作记录
    # SQLALCHEMY_ECHO = True
    # 说明: 设置每次请求结束后都自动提交数据库变动
    # SQLALCHEMY_COMMIT_ON_TEARDOWN = False
    # 说明: 显式启用查询记录,调试模式自动启用
    # SQLALCHEMY_RECORD_QUERIES = True
    # 说明: 显式启用数据库引擎Unicode支持
    # SQLALCHEMY_NATIVE_UNICODE = True
    # 说明: 设置数据库连接池大小,默认值5s
    # SQLALCHEMY_POOL_SIZE = 5
    # 说明: 设置数据库连接池超时时间,默认10s
    # SQLALCHEMY_POOL_TIMEOUT = 10
    # 说明: 设置自动回收闲置连接的秒数,默认2小时,使用MySQL引擎必备
    # SQLALCHEMY_POOL_RECYCLE = 7200
    # 说明: 设置连接池达到最大连接数时可以创建的连接数
    # SQLALCHEMY_MAX_OVERFLOW = 5
    # 说明: 设置追踪对象修改并发送信号,调试时可开启
    # SQLALCHEMY_TRACK_MODIFICATIONS = True

    @staticmethod
    def init_app(app):
        pass


# 说明: Flask扩展开发环境配置子类
class __DevelopmentConfig(__Config):
    #
    # For flask-bootstrap
    #
    BOOTSTRAP_SERVE_LOCAL = True
    #
    # For flask-sqlalchemy
    # create database xmdevops default charset utf8 collate utf8_general_ci;
    #
    SQLALCHEMY_ECHO = True
    SQLALCHEMY_RECORD_QUERIES = True
    SQLALCHEMY_NATIVE_UNICODE = True
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    SQLALCHEMY_COMMIT_ON_TEARDOWN = True
    SQLALCHEMY_DATABASE_URI = 'mysql://root:root@10.2.5.51/xmdevops'


# 说明: Flask扩展预测试环境配置子类
class __TestingConfig(__Config):
    #
    # For flask-bootstrap
    #
    BOOTSTRAP_SERVE_LOCAL = True
    #
    # For flask-sqlalchemy
    # create database xmdevops default charset utf8 collate utf8_general_ci;
    #
    SQLALCHEMY_ECHO = True
    SQLALCHEMY_RECORD_QUERIES = True
    SQLALCHEMY_NATIVE_UNICODE = True
    SQLALCHEMY_TRACK_MODIFICATIONS = True
    SQLALCHEMY_COMMIT_ON_TEARDOWN = True
    SQLALCHEMY_DATABASE_URI = 'mysql://root:root@10.2.5.51/xmdevops'


# 说明: Flask扩展正式环境配置子类
class __ProductionConfig(__Config):
    pass

config = {
    'default': __DevelopmentConfig,
    'develop': __DevelopmentConfig,
    'testing': __TestingConfig,
    'product': __ProductionConfig,
}
